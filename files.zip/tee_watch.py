import json, os, sys, datetime as dt
import requests

# TIMES_URL is the foreUP "times" request you copy from Chrome's Network tab,
# with the date swapped for the placeholder {date}  (format MM-DD-YYYY).
TIMES_URL = os.environ["TIMES_URL"]
WEBHOOK = os.environ["DISCORD_WEBHOOK"]
COOKIE = os.getenv("FOREUP_COOKIE", "")          # only needed if the site requires login
DAYS_AHEAD = int(os.getenv("DAYS_AHEAD", "14"))  # how many days out to check
WEEKENDS_ONLY = os.getenv("WEEKENDS_ONLY", "false").lower() == "true"
EARLIEST = os.getenv("EARLIEST", "06:00")        # 24h HH:MM
LATEST = os.getenv("LATEST", "14:00")
MIN_SPOTS = int(os.getenv("MIN_SPOTS", "2"))
SEEN_FILE = "seen.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "X-Requested-With": "XMLHttpRequest",
}
if COOKIE:
    HEADERS["Cookie"] = COOKIE


def load_seen():
    try:
        with open(SEEN_FILE) as f:
            return set(json.load(f))
    except Exception:
        return set()


def save_seen(seen):
    today = dt.date.today().isoformat()
    keep = sorted(k for k in seen if k[:10] >= today)  # drop past dates
    with open(SEEN_FILE, "w") as f:
        json.dump(keep, f, indent=0)


def fetch_day(day):
    url = TIMES_URL.replace("{date}", day.strftime("%m-%d-%Y"))
    r = requests.get(url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, list):
        raise ValueError(f"Unexpected response (login needed?): {str(data)[:200]}")
    return data


def main():
    seen = load_seen()
    found = []
    today = dt.date.today()
    for i in range(DAYS_AHEAD + 1):
        day = today + dt.timedelta(days=i)
        if WEEKENDS_ONLY and day.weekday() < 5:
            continue
        try:
            slots = fetch_day(day)
        except Exception as e:
            print(f"{day}: error {e}", file=sys.stderr)
            continue
        for s in slots:
            t = s.get("time", "")          # e.g. "2026-11-15 07:30"
            if len(t) < 16:
                continue
            hhmm = t[11:16]
            spots = int(s.get("available_spots", 0) or 0)
            if not (EARLIEST <= hhmm <= LATEST) or spots < MIN_SPOTS:
                continue
            key = f"{t}|{s.get('schedule_id', '')}"
            if key in seen:
                continue
            seen.add(key)
            when = dt.datetime.strptime(t[:16], "%Y-%m-%d %H:%M").strftime("%a %b %d, %I:%M %p")
            fee = s.get("green_fee")
            found.append(f"{when} - {spots} spots" + (f" - ${fee}" if fee else ""))

    if found:
        msg = "⛳ **Torrey Pines tee times open:**\n" + "\n".join(found[:25])
        requests.post(WEBHOOK, json={"content": msg[:1900]}, timeout=20)
        print(f"Notified about {len(found)} times")
    else:
        print("Nothing new")
    save_seen(seen)


if __name__ == "__main__":
    main()
